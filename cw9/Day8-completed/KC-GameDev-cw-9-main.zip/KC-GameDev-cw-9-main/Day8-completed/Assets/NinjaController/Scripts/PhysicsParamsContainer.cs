﻿using UnityEngine;

namespace NinjaController {
  public class PhysicsParamsContainer : MonoBehaviour {

    public PhysicsParams physicsParams;
  }
}
